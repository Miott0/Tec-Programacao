package Numero1;

public class Pilha implements TAD {
	
	No topo = null;

	@Override
	public void push(char dado) {
		No novoNo = new No(dado);
		novoNo.setProximo(this.topo);
		this.topo = novoNo;
	}

	@Override
	public char pop() {
		char dado = this.topo.getDado();
		this.topo = this.topo.getProximo();
		return dado;
	}
	
	@Override
	public char getTop() {
		return this.topo.getDado();
	}

	@Override
	public boolean vazio() {
		return this.topo == null;
	}
	
	@Override
	public String toString() {
		String elementos = new String();
		No noAtual = this.topo;
		while(noAtual != null) {
			elementos = elementos + noAtual.getDado() + " ";
			noAtual = noAtual.getProximo();
		}
		return "Pilha encadeada	[ " + elementos + "]";
	}

}
