package Numero1;

public interface TAD {

	public void push(char dado);
	
	public char pop();
	
	public boolean vazio();
	
	public char getTop();
	
	@Override
	public String toString();
	
	
}
