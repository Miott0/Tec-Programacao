package Numero1;
import java.util.Scanner;

public class Teste {

	public static String inverter(String s) {
    Pilha pilha = new Pilha();
    for (int i = 0; i < s.length(); i++) {
     	pilha.push(s.charAt(i));
    }

    String inverso = "";
    
	while(!pilha.vazio()){
		inverso += pilha.pop();
	}
	return inverso;

  }
  		

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.print("Digite uma frase de até 20 caracteres: ");
    String frase = scanner.nextLine();

    System.out.println("Frase invertida: " + inverter(frase));
  }
}
